# A library capable of removing outliers from a pandas dataframe

```
PROJECT 2, UCS633 - Data Analysis and Visualization
Nishant Dhanda 
COE17
Roll number: 101703375
```
